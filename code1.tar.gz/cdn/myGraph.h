#ifndef __MYGRAPH_H_
#define __MYGRAPH_H_

#include <cstdlib>
#include <iostream>
#include <sstream>
#include <iomanip>

struct User;  
struct Vertex;  
struct Edge  
{  
    int Vstart;  
    int Vend;  
    int Egbps;  
    int Ecost;  
    int Fij;    //������fij  
    Edge * next;  
    Edge(int vs, int ve, int eg, int ec, int fij):Vstart(vs),Vend(ve),Egbps(eg),Ecost(ec),Fij(fij),next(NULL){}  
};  
struct Vertex  
{  
    int outNum;  
    int outGbps;  
    Edge * head;  
    Vertex():outNum(0),outGbps(0),head(NULL){};  
};  
struct User  
{  
    int Unode;  
    int Ugbps;  
    User():Unode(-1),Ugbps(-1){}  
};  
class myGraph  
{  
public:  
    int Vnum;//����ڵ�����������������ѽڵ㣩  
    int Enum;//����  
    int Unum;//���ѽڵ����  
    Vertex * V;//ԭͼ����ڵ�  
    User * U;//���ѽڵ�  
    int * boolV;//�������������  
    int FijMax;//�����  
    Vertex * VF;//�д�ͼ����ڵ�  
    int ** Map;//·��ת�ƾ���  
    int ** MapCost;//��С·���ɱ�����  
    myGraph():Vnum(0),Enum(0),Unum(0),V(NULL),U(NULL),boolV(NULL),FijMax(0),VF(NULL),Map(NULL),MapCost(NULL){}  
    myGraph(int vn, int en, int un):Vnum(vn+1),Enum(2*en),Unum(un)  
    {  
        V = new Vertex[Vnum];  
        U = new User[Unum];  
        boolV = new int[Vnum];  
        for (int i = 0; i < Vnum; i++)  
            boolV[i] = 0;  
  
        FijMax = 0;  
        VF = NULL;  
        Map = NULL;  
        MapCost = NULL;  
    }  
    ~myGraph()  
    {  
        for (int i = 0; i < Vnum; i++)  
        {  
            Edge * eh = V[i].head;  
            while (eh != NULL)  
            {  
                Edge * del = eh;  
                eh = eh->next;  
                delete del;  
            }  
        }  
        delete [] V;  
        V = NULL;  
        delete [] U;  
        U = NULL;  
        delete [] boolV;  
        boolV = NULL;  
  
        if (VF != NULL)  
        {  
            for (int i = 0; i < Vnum; i++)  
            {  
                Edge * eh = VF[i].head;  
                while (eh != NULL)  
                {  
                    Edge * del = eh;  
                    eh = eh->next;  
                    delete del;  
                }  
            }  
            delete [] VF;  
        }  
        VF = NULL;  
        if (Map != NULL)  
        {  
            for (int i = 0; i < Vnum; i++)  
                delete [] Map[i];  
            delete [] Map;  
        }  
        Map = NULL;  
        if (MapCost != NULL)  
        {  
            for (int i = 0; i < Vnum; i++)  
                delete [] MapCost[i];  
            delete [] MapCost;  
        }  
        MapCost = NULL;  
    }  
  
    myGraph(const myGraph &g);  
    void AddSingleEdge(int vs, int ve, int eg, int ec);  
    void AddUser(int u, int un, int ug);  
  
    void createVF();  
    void createMap();  
    void setMap();  
  
    long countCost(int service, int * Node);  
    long countPathCost(int serviceCost);  
    int finMinPathCost();  
    void addFij(int vs, int ve, int fij);  
  
    void finalOut();  
    int searchPath(int Node, int f);  
    void outStack(int f);  
  
    void showGraph();  
    int * topOutNode();  
    int * topGbpsNode();  
    void mapSort(int * bird0, int * birdk);  
  
    long birds(int serviceCost);  
};  
#endif
