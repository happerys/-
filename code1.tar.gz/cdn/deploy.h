#ifndef __DEPLOY_H__
#define __DEPLOY_H__

#include "lib_io.h"
#include <stdlib.h>
#include <string>
#include <iostream>
#include<sstream>

void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename);

#endif
